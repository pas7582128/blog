<?php
require_once('config.php');
session_start();
session_destroy();

header('Location:'. APP_ROOT . '/youtube/20171216/'); exit;