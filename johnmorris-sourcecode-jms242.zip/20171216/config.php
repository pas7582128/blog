<?php
require_once('appdata.php');

$users = array(
    array(
        'id' => 1,
        'username' => 'john',
        'password' => 'morris',
    ),
    array(
        'id' => 2,
        'username' => 'don',
        'password' => 'juan',
    )
);