<h1>Login</h1>
<form action="process.php" method="post">
    <input type="text" name="username">
    <input type="password" name="password">
    <input type="submit" value="submit">
</form>
    